
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Frases extends Canvas{
    protected int contador=0, x,y,desplazamientoX=10,desplazamientoY=10;
    Color colorRelleno;
    public Frases(){
        hmover.start(); //Lo movemos el string
        h.start(); //El hilo de los 20 segundos que cambie el arreglo y repinte el string
        
    }
    Thread h = new Thread(new Runnable(){
    @Override
        public void run() {
            while(true){
                try {
                    contador++;
                    if(contador == frases.length){
                        contador=0;
                    }
                    repaint();
                    Thread.sleep(20000);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Frases.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
            
    });
    Thread hmover = new Thread(new Runnable(){
    @Override
        public void run() {
            while(true){
                try {
                    x+= desplazamientoX;
                    y+= desplazamientoY;
                    if(x <= 0){
                        desplazamientoX=10;
                    }
                    if(x>=1018){
                        desplazamientoX=-10;
                    }
                   if(y<=0){
                        desplazamientoY=10;
                    }
                    if(y>=479){
                        desplazamientoY=-10;
                    }
                    repaint();
                    Thread.sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Frases.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
            
    });
    String[] frases = new String[]{
        "La libertad no necesita alas, lo que necesita es echar raíces",
        "El pasado está escrito en la memoria y el futuro presente en el deseo",
        "El respeto al derecho ajeno es la paz",
        "Si vivir es solo soñar, hagamos el bien soñando",
        "El Indulto es para los criminales, no para los defensores de la patria",
        "Un buen gobierno solamente puede existir cuando hay buenos ciudadanos",
        "Con estos acontecimientos comprendo que los que deseábamos un cambio, nada debíamos esperar de arriba",
        "Sufragio efectivo, no reelección",
        "El poder público no puede tener otro origen ni otra base que la voluntad nacional",
        "Al conquistar nuestras libertades hemos conquistado una nueva arma; esa arma es el voto",
        "La tierra es para quien la trabaja",//10
        "Quiero morir siendo esclavo de los principios, no de los hombres",
        "Perdono al que roba y al que mata, pero al que traiciona, nunca",
        "El que quiera ser águila que vuele, el que quiera ser gusano que se arrastre pero que no grite cuando lo pisen",
        "La ignorancia y el oscurantismo en todos los tiempos no han producido más que rebaños de esclavos para la tiranía",
        "El país debe ser gobernado por alguien que realmente quiera a su gente y a su tierra y que comparta la riqueza y el progreso",
        "Nadie hace bien lo que no sabe; por consiguiente nunca se hará República con gente ignorante, sea cual fuere el plan que se adopte",
        "Ya es tiempo de que los prejuicios acaben, de que la sociedad se establezca sobre bases más sólidas, más naturales, más sabias, más justas y más nobles",
        "La incultura es una de las desgracias más grandes de mi raza",
        "La educación de los hijos de mi raza es algo que no debe pasar inadvertido para los gobernantes y para los ciudadanos.",
        "Nunca al problema educativo se le ha dado la atención necesaria",//20
        "Para servir a la patria nunca sobra el que llega ni hace falta el que se va",
        "Se respetará escrupulosamente el espíritu liberal de la Constitución",
        "Nosotros representamos la legalidad durante la lucha armada, y actualmente somos los revolucionarios",
        "Si cada uno de los mexicanos hiciera lo que le corresponde, la patria estaría salvada",
        "Al conquistar nuestras libertades hemos conquistado una nueva arma; esa arma es el voto",
        "Viviré hasta que haya alguien que cambie su vida por la mía",
        "La República ha entrado francamente en la vía de un progreso incuestionable",
        "Yo estoy resuelto a luchar contra todo y contra todos sin más baluarte que la confianza y el apoyo de mi pueblo",
        "Si no hay justicia para el pueblo, que no haya paz para el gobierno",
        "Tierra y Libertad",
        "La rebeldía es la vida: la sumisión es la muerte",
        "Sufragio efectivo, no reelección",
        "Pobre de México, tan lejos de Dios y tan cerca de los Estados Unidos",
        "Madero ha despertado al tigre, veremos si es capaz de domarlo",
        "Prometo a usted, señor presidente, que mañana todo habrá terminado",
        "Más que militar, soy revolucionario de ideas, y llegado el caso, esgrimo la palabra, la pluma o las armas",
        "Ahí te van las hojas, mándame más tamales",
        "La verdadera misión del ejército consiste, no en apoyar incondicionalmente a cualquier personaje que se declara amo de un pueblo cuando sea oprimido",
        "Fuimos muy duros, algunas veces hasta llegar a la crueldad",
        "Lo que el pueblo necesita para gozar de libertades es su emancipación económica"
    };
    @Override
    public void paint(Graphics g) {
        Graphics2D g2 = (Graphics2D)g;
        g2.setColor(new Color((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255)));
        g.setFont(new Font("Arial", Font.BOLD, 15));
        g2.drawString(frases[contador], x, y);
        g2.setBackground(Color.white);
    }
}

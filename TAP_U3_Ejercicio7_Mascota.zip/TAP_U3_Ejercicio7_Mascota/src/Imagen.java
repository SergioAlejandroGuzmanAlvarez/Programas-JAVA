import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.image.ImageObserver;
import javax.swing.ImageIcon;
public class Imagen {
    protected int x,y;
    protected Image imagen;
    protected int ancho,alto, anchoImagen, altoImagen;
    public Imagen(String nombreImagen, int posX, int posY, int anchoI, int altoI, Inicio puntero){
        x = posX;
        y = posY;
        imagen = new ImageIcon(puntero.getClass().getResource("/"+nombreImagen)).getImage();
        anchoImagen = anchoI;
        altoImagen = altoI;
        ancho = imagen.getWidth(puntero);
        alto =imagen.getHeight(puntero);
        
    }
    public Imagen(String nombreImagen, int posX, int posY, int anchoI, int altoI, Mascota puntero){
        x = posX;
        y = posY;
        imagen = new ImageIcon(puntero.getClass().getResource("/"+nombreImagen)).getImage();
        anchoImagen = anchoI;
        altoImagen = altoI;
        ancho = imagen.getWidth(puntero);
        alto =imagen.getHeight(puntero);
        
    }
    public boolean estaEnArea(int posXRaton, int posYRaton){
        int x2 = x + ancho;
        int y2 = y + alto;
        if(posXRaton>=x&&posXRaton<=x2){
            if(posYRaton>=y&&posYRaton<=y2){
                return true;
            }
        }
        return false;
    }
    public void mover(int posXRaton, int posYRaton){
        x=posXRaton - ancho/2;
        y=posYRaton - alto/2;
    }
    public boolean colision(Imagen objetoA){
        /*
         4 PUNTOS
            1= X2,Y
            2= X,Y2
            3= X,Y
            4= X2,Y2
        */
        int X2ObjetoA = objetoA.x+objetoA.ancho;
        int Y2ObjetoA = objetoA.y+objetoA.alto;
        if(estaEnArea(objetoA.x,objetoA.y)){
            return true;
        }
        if(estaEnArea(objetoA.x,Y2ObjetoA)){
            return true;
        }
        if(estaEnArea(objetoA.x,objetoA.y)){
            return true;
        }
        if(estaEnArea(X2ObjetoA,Y2ObjetoA)){
            return true;
        }
        return false;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
    
}

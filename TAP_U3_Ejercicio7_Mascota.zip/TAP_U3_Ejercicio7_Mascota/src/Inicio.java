
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Inicio extends JPanel {
    //777, 497
    Imagen fondo = new Imagen("Imagenes/olas.jpg",0,0,1100,570,this); //fondo
    Imagen boton = new Imagen("Imagenes/boton.png",380,350,200,150,this); //boton
    Imagen img4 = new Imagen("Imagenes/icono1.png",73,130,300,300,this); //Pandita 2
    Imagen img5 = new Imagen("Imagenes/gatito.png",480,130,300,300,this); //Gato
    Imagen img6 = new Imagen("Imagenes/conejo.png",860,130,300,300,this); //conejo
    Lienzo puntero;
    Graphics2D g2;
    public Inicio(Lienzo p){
       this.puntero=p;
    }
    public void pintarPantalla(Graphics g){
        g2 = (Graphics2D)g;
        g2.setBackground(Color.white);
        g2.drawImage(fondo.imagen, fondo.x, fondo.y, fondo.anchoImagen, fondo.altoImagen, this);
        g2.drawImage(boton.imagen, boton.x, boton.y, boton.anchoImagen, boton.altoImagen, this);
    }
    public void pintarSeleccion(Graphics g){
       g2 = (Graphics2D)g;
       g2.setColor(new Color(0,0,0));
       g2.setFont(new Font("Arial", Font.PLAIN, 35));
       g2.drawString("Selecciona tu mascota",450,30);
       g2.setStroke(new BasicStroke(4));
       
       g2.setColor(new Color(37, 34, 33));
       g2.fillRect(0, 40, 1259,545);
       g2.setColor(new Color(63, 56, 54));
       g2.drawRect(0, 40, 1259,545);
       
       
       g2.setColor(new Color(65, 46, 42));
       g2.fillOval(50, 100, 350,350);
       g2.setColor(Color.black);   
       g2.drawOval(50, 100, 350,350);
       g2.drawImage(img4.imagen, img4.x, img4.y, img4.anchoImagen, img4.altoImagen, this); // Mascota
    
       g2.setColor(new Color(65, 46, 42));
       g2.fillOval(450, 100, 350, 350);
       g2.setColor(Color.black);   
       g2.drawOval(450, 100, 350, 350);
       g2.drawImage(img5.imagen, img5.x, img5.y, img5.anchoImagen, img5.altoImagen, this); // Mascota
       
       g2.setColor(new Color(65, 46, 42));
       g2.fillOval(840, 100, 350, 350);
       g2.setColor(Color.black);   
       g2.drawOval(840, 100, 350, 350);
       g2.drawImage(img6.imagen, img6.x, img6.y, img6.anchoImagen, img6.altoImagen, this); // Mascota
    }
}


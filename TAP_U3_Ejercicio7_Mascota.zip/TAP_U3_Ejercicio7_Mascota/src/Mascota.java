
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Mascota extends JPanel{
    protected String nombre;
    protected int hambre, agua, limpieza, diversion, accion;
    protected int edad;
    protected String origen="";
    Graphics2D g2;
    protected Imagen img2 = new Imagen("Imagenes/comida.png",170,50,70,70,this); //Comida
    protected Imagen img3 = new Imagen("Imagenes/agua.png",400,50,70,70,this); //Agua
    protected Imagen img4 = new Imagen("Imagenes/jabon.png",720,50,70,70,this); //Limpieza
    protected Imagen img5 = new Imagen("Imagenes/pelota.png",990,50,70,70,this); //Pelota
    protected Imagen img6 = new Imagen("Imagenes/fuji.png",250,210,500,500,this); //Fuji
    protected Imagen img7 = new Imagen("Imagenes/patio.jpg",170,132,930,430,this); //Patio
    Lienzo puntero;
    Tamagotchi m;
    protected int imageX=170,imageY=400;
    protected int imageX2=800,imageY2=400;
    protected String sprite="mov", sprite2="inv";
    protected int numero=1,control=1;
    public Mascota(Lienzo p){
        this.puntero=p;
        
    }
    public Mascota(String nombre, int hambre, int agua, int limpieza, int diversion) {
        this.nombre = nombre;
        this.hambre = hambre;
        this.agua = agua;
        this.limpieza = limpieza;
        this.diversion = diversion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getHambre() {
        return hambre;
    }

    public void setHambre(int hambre) {
        this.hambre = hambre;
    }

    public int getAgua() {
        return agua;
    }

    public void setAgua(int agua) {
        this.agua = agua;
    }

    public int getLimpieza() {
        return limpieza;
    }

    public void setLimpieza(int limpieza) {
        this.limpieza = limpieza;
    }

    public int getDiversion() {
        return diversion;
    }

    public void setDiversion(int diversion) {
        this.diversion = diversion;
    }

    public int getAccion() {
        return accion;
    }

    public void setAccion(int accion) {
        this.accion = accion;
    }
    public void pintarEscenario(Graphics g){
        g2 = (Graphics2D)g;
        g2.setColor(new Color(77, 129, 125));
        g2.fillRect(0, 10, 1300, 120);
        g2.drawRect(0, 10, 1300, 120);
        g2.drawImage(img7.imagen, img7.x, img7.y, img7.anchoImagen, img7.altoImagen,this); // Aburrido
        g2.drawRect(0,130,168,414);
        g2.setColor(new Color(80, 157, 151));
        g2.fillRect(0,130,168,414);
        g2.fillRect(1100,130,161,414);
        g2.drawRect(1100,130,161,414);
        g2.drawImage(img2.imagen, img2.x, img2.y, img2.anchoImagen, img2.altoImagen,this); // Hambre
        g2.drawImage(img3.imagen, img3.x, img3.y, img3.anchoImagen, img3.altoImagen,this); // Agua
        g2.drawImage(img4.imagen, img4.x, img4.y, img4.anchoImagen, img4.altoImagen,this); // Limpieza
        g2.drawImage(img5.imagen, img5.x, img5.y, img5.anchoImagen, img5.altoImagen,this); // Aburrido
    }
    public void pintarMascota(Graphics g){
        Graphics2D g2;
        g2 =(Graphics2D)g;
        switch(control){
            case 1:
                ImageIcon sprites = new ImageIcon(new ImageIcon(getClass().getResource("SPRITES/"+sprite+numero+".png")).getImage());
                g2.drawImage(sprites.getImage(),imageX,imageY,100,100,null);
            break;
            case 2:
                ImageIcon sprites2 = new ImageIcon(new ImageIcon(getClass().getResource("SPRITES/"+sprite2+numero+".png")).getImage());
                g2.drawImage(sprites2.getImage(),imageX2,imageY,100,100,null);
            break;
        }
    }  
    
    /*public void pintarAnimacion(int valor){
        Graphics g = null;
        g2 = (Graphics2D)g;
        g2.setColor(Color.black);
        g2.setFont(new Font("Arial", Font.PLAIN, 20));
        switch(valor){
            case 0:
                
                break;
            case 1:
                break;
            case 2:
                break;
            case 3:
                break;
        }
        g2.drawString("Agua",410,100);
        g2.drawString("Limpieza",720,100);
        g2.drawString("Jugar",1000,100);
    }*/
}

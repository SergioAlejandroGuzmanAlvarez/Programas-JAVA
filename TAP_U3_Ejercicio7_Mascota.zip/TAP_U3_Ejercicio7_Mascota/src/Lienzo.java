
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Lienzo extends JPanel {
    int estado=0;
    Inicio ini = new Inicio(this);
    Mascota m = new Mascota(this);
    Tamagotchi puntero;
    Graphics2D g2;
    Graphics gp;
    public Lienzo(Tamagotchi p){
        this.puntero=p;
        //setBounds(0,0,1300,545);
        addMouseListener(new MouseListener(){
           @Override
           public void mouseClicked(MouseEvent e) {
               if(ini.boton.estaEnArea(e.getX(), e.getY())){
                    int r=JOptionPane.showConfirmDialog(null, "Bienvenido a tu mascota virtual, al parecer no tienes ninguna mascota registrada"
                            + "\n ¿Deseas registrar una nueva mascota?", "Nueva mascota", 1);
                    if(r==JOptionPane.YES_OPTION){
                        estado=1;
                        repaint();
                    }
               }
               if(ini.img4.estaEnArea(e.getX(), e.getY())){
                    String cad = JOptionPane.showInputDialog("¡Eligste un pandita!\n ¿Cuál sera el nombre para tu mascota?");
                    m= new Mascota(cad,100,100,100,100);
                    estado=2;
                    repaint();    
                    if(estado==2) t.start(); puntero.comprobar();
                            
               }
               if(m.img2.estaEnArea(e.getX(),e.getY())){
                   int aux=puntero.jpbHambre.getValue();
                   puntero.jpbHambre.setValue(aux+(5));
               }
               if(m.img3.estaEnArea(e.getX(),e.getY())){
                   int aux=puntero.jpbSed.getValue();
                   puntero.jpbSed.setValue(aux+(5));
               }
               if(m.img4.estaEnArea(e.getX(),e.getY())){
                   int aux=puntero.jpbLimpieza.getValue();
                   puntero.jpbLimpieza.setValue(aux-(5));
               }
               if(m.img5.estaEnArea(e.getX(),e.getY())){
                   int aux=puntero.jpbAburrimiento.getValue();
                   puntero.jpbAburrimiento.setValue(aux-(5));
               }
           }

           @Override
           public void mousePressed(MouseEvent e) {
               //
           }

           @Override
           public void mouseReleased(MouseEvent e) {
               //
           }

           @Override
           public void mouseEntered(MouseEvent e) {
           }

           @Override
           public void mouseExited(MouseEvent e) {
               //
           }  
       });
        
    }
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g2 =(Graphics2D) g;
        switch(estado){
            case 0:
                ini.pintarPantalla(g);
            break;
            case 1:
                ini.pintarSeleccion(g);
            break;
            case 2:
                m.pintarEscenario(g);
                m.pintarMascota(g);
            break;
        }
    }
    Thread t = new Thread(new Runnable(){
        @Override
        public void run() {
            while(true){
                try {
                    if(m.imageX>=50 && m.imageX<=800){ 
                        m.numero++;
                        if(m.numero==18){
                            m.numero=1;
                        }
                        m.imageX+=10;
                    }
                    else if(m.imageX2>=800 || m.imageX2<=800){
                        m.control=2;
                        m.numero++;
                        if(m.numero==18){
                            m.numero=1;
                        }
                        m.imageX2-=10;
                        if(m.imageX2<=150){ m.control=1; m.imageX2=800; m.imageX=150;}
                    }
                    repaint();
                    Thread.sleep(100);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Lienzo.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    });
}

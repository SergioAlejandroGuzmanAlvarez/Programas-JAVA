
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Tamagotchi extends javax.swing.JFrame {
    /*777, 497 */
    Lienzo l = new Lienzo(this);
    int aux1=0,aux2=0,aux3=0,aux4=0;
    Mascota m;
    
    /**
     * Creates new form Tamagotchi
     */
    public void ocultar(){
        jpbAburrimiento.setVisible(false);
        jpbHambre.setVisible(false);
        jpbLimpieza.setVisible(false);
        jpbSed.setVisible(false);
        lblAburrido.setVisible(false);
        lblHambre.setVisible(false);
        lblSed.setVisible(false);
        lblSucio.setVisible(false);
    }
    public void comprobar(){
        if(l.estado==2){
            jpbAburrimiento.setVisible(true);
            jpbHambre.setVisible(true);
            jpbLimpieza.setVisible(true);
            jpbSed.setVisible(true);
            lblAburrido.setVisible(true);
            lblHambre.setVisible(true);
            lblSed.setVisible(true);
            lblSucio.setVisible(true);
            timerAburrido.start();
            timerAgua.start();
            timerHambre.start();
            timerSucio.start();
        }
    }
    public Tamagotchi() {
        initComponents();
        setLocationRelativeTo(null); //La centramos
        l.setSize(1110, 558); //Asignamos un tamaño al canvas
        add(l); //Añadimos el canvas
        this.setResizable(false); //Quitamos la opcion de maximizar
        ocultar();
        //comprobar();
    }
    Timer timerHambre = new Timer(1080, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
            aux1 = jpbHambre.getValue();
            if(aux1<=100){
                if(aux1==100){
                    lblHambre.setText("*-Sin hambre-*");
                }else if(aux1==80){
                    lblHambre.setText("*-Estomago cruge-*");
                }else if(aux1==50){
                    lblHambre.setText("*-Hambre-*");
                }else if(aux1==30){
                    lblHambre.setText("*-Alimentame-*");
                }else if(aux1==10){
                    lblHambre.setText("*-Vomita-*");
                }else if(aux1<10){
                    lblHambre.setText("*-Muerte lenta-*");
                }
                aux1--;
                jpbHambre.setValue(aux1);
            }else{
                timerHambre.stop();
            }
        }
    });
    Timer timerAgua = new Timer(2000, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
            aux2 = jpbSed.getValue();
            if(aux2<=100){
                if(aux2==100){
                    lblSed.setText("*-Sin sed-*");
                }else if(aux2==80){
                    lblSed.setText("*-Labios secos-*");
                }else if(aux2==50){
                    lblSed.setText("*-Con sed-*");
                }else if(aux2==30){
                    lblSed.setText("*-Sediento-*");
                }else if(aux2==10){
                    lblSed.setText("*-Desidratado-*");
                }else if(aux2<10){
                    lblSed.setText("Tengo mucha sed");
                }
                aux2--;
                jpbSed.setValue(aux2);
            }else{
                timerAgua.stop();
            }
        }
    });
    Timer timerSucio = new Timer(1000, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
            aux3 = jpbLimpieza.getValue();
            if(aux3<=100){
                if(aux3>=5){
                    lblSucio.setText("Huele raro");
                }else if(aux3>=10){
                    lblSucio.setText("Mi pelo huele feo");
                }else if(aux3>=50){
                    lblSucio.setText("Me huelen las axilas");
                }else if(aux3>=70){
                    lblSucio.setText("Llevo 3 días sin bañarme");
                }else if(aux3>=90){
                    lblSucio.setText("Auxilio, me desmayo");
                }else if(aux3>100){
                    lblSucio.setText("Sucio como puerco");
                }
                aux3++;
                jpbLimpieza.setValue(aux3);
            }else{
                timerSucio.stop();
            }
        }
    });
    Timer timerAburrido = new Timer(1000, new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e) {
            aux4 = jpbAburrimiento.getValue();
            if(aux4<=100){
                if(aux4>=5){
                    lblAburrido.setText("Tranquilo");
                }else if(aux4>=10){
                    lblAburrido.setText("Con ganas de jugar");
                }else if(aux4>=50){
                    lblAburrido.setText("¿Jugamos?");
                }else if(aux4>=70){
                    lblAburrido.setText("Voy a llorar");
                }else if(aux4>=90){
                    lblAburrido.setText("Con uno me basta");
                }else if(aux4>100){
                    lblAburrido.setText("Aburridisimo");
                }
                aux4++;
                jpbAburrimiento.setValue(aux4);
            }else{
                timerAburrido.stop();
            }
        }
    });
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnlArriba = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jpbHambre = new javax.swing.JProgressBar();
        jpbSed = new javax.swing.JProgressBar();
        jpbLimpieza = new javax.swing.JProgressBar();
        jpbAburrimiento = new javax.swing.JProgressBar();
        lblHambre = new javax.swing.JLabel();
        lblSed = new javax.swing.JLabel();
        lblSucio = new javax.swing.JLabel();
        lblAburrido = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(777, 497));

        pnlArriba.setBackground(new java.awt.Color(21, 34, 40));

        javax.swing.GroupLayout pnlArribaLayout = new javax.swing.GroupLayout(pnlArriba);
        pnlArriba.setLayout(pnlArribaLayout);
        pnlArribaLayout.setHorizontalGroup(
            pnlArribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        pnlArribaLayout.setVerticalGroup(
            pnlArribaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 40, Short.MAX_VALUE)
        );

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jpbHambre.setValue(100);

        jpbSed.setValue(100);

        lblHambre.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 18)); // NOI18N
        lblHambre.setForeground(new java.awt.Color(153, 0, 0));
        lblHambre.setText("Hambre");

        lblSed.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 18)); // NOI18N
        lblSed.setForeground(new java.awt.Color(0, 0, 51));
        lblSed.setText("Sed");

        lblSucio.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 18)); // NOI18N
        lblSucio.setForeground(new java.awt.Color(0, 102, 51));
        lblSucio.setText("Limpieza");

        lblAburrido.setBackground(new java.awt.Color(153, 102, 0));
        lblAburrido.setFont(new java.awt.Font("Arial Rounded MT Bold", 0, 18)); // NOI18N
        lblAburrido.setForeground(new java.awt.Color(204, 102, 0));
        lblAburrido.setText("Aburrimiento");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jpbHambre, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jpbLimpieza, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jpbSed, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jpbAburrimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGap(10, 10, 10))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lblSed)
                        .addGap(45, 45, 45))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lblAburrido)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lblSucio)
                        .addGap(19, 19, 19))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(lblHambre)
                        .addGap(26, 26, 26))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(jpbHambre, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblHambre)
                .addGap(44, 44, 44)
                .addComponent(jpbSed, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(lblSed)
                .addGap(48, 48, 48)
                .addComponent(jpbLimpieza, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addComponent(lblSucio)
                .addGap(18, 18, 18)
                .addComponent(jpbAburrimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblAburrido)
                .addContainerGap(84, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pnlArriba, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 1098, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pnlArriba, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tamagotchi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tamagotchi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tamagotchi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tamagotchi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tamagotchi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    public javax.swing.JProgressBar jpbAburrimiento;
    public javax.swing.JProgressBar jpbHambre;
    public javax.swing.JProgressBar jpbLimpieza;
    public javax.swing.JProgressBar jpbSed;
    public javax.swing.JLabel lblAburrido;
    public javax.swing.JLabel lblHambre;
    public javax.swing.JLabel lblSed;
    public javax.swing.JLabel lblSucio;
    public javax.swing.JPanel pnlArriba;
    // End of variables declaration//GEN-END:variables
}

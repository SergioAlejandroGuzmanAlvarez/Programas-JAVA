
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class SemaforoA extends Thread{
    Lienzo puntero;
    protected int sem=0;
    public SemaforoA(Lienzo l){
        this.puntero=l;
    }
    public void pintarSemaforoA(Graphics2D g2){
        g2.setColor(Color.ORANGE);
        g2.setStroke(new BasicStroke(3));
        g2.fillRect(450, 440, 90, 180);
        g2.setColor(Color.black);
        g2.drawRect(450, 440, 90, 180);
        //Palo A
        g2.setColor(Color.ORANGE);
        g2.setStroke(new BasicStroke(3));
        g2.fillRect(480, 625, 30,60);
        g2.setColor(Color.black);
        g2.drawRect(480, 625, 30,60);
    }
    public void controlSemaforo (Graphics2D g2){
        switch(sem){
            case 1:
                //Rojo A
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(473, 460,45,45);
                g2.setColor(Color.black);
                g2.drawOval(473, 460,45,45);
                //Amarillo A
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(473, 515,45,45);
                g2.setColor(Color.black);
                g2.drawOval(473, 515,45,45);
                //Verde A
                g2.setColor(Color.GREEN);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(473, 570,45,45);
                g2.setColor(Color.black);
                g2.drawOval(473, 570,45,45);
            break;
            case 2:
                //Rojo A
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(473, 460,45,45);
                g2.setColor(Color.black);
                g2.drawOval(473, 460,45,45);
                //Amarillo A
                g2.setColor(new Color(232,248,5));
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(473, 515,45,45);
                g2.setColor(Color.black);
                g2.drawOval(473, 515,45,45);
                //Verde A
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(473, 570,45,45);
                g2.setColor(Color.black);
                g2.drawOval(473, 570,45,45);
            break;
            case 3:
                //Rojo A
                g2.setColor(new Color(232,10,33));
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(473, 460,45,45);
                g2.setColor(Color.black);
                g2.drawOval(473, 460,45,45);
                //Amarillo A
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(473, 515,45,45);
                g2.setColor(Color.black);
                g2.drawOval(473, 515,45,45);
                //Verde A
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(473, 570,45,45);
                g2.setColor(Color.black);
                g2.drawOval(473, 570,45,45);
            break;
        }
    }
    public void ColorVerde(){ //Cada uno representa un proceso, un estado de cambio de semaforo
        sem=1;
        puntero.repaint(); 
    }
    public void ColorAma(){
        sem=2;
        puntero.repaint();
    }
    public void ColorRojo(){
        sem=3;
        puntero.repaint();
    }
    @Override
    public void run() {
        while(true){
            try {
                ColorVerde();
                sleep(10000);
                ColorAma();
                sleep(5000);
                ColorRojo();
                sleep(10000);
                ColorAma();
                sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SemaforoA.class.getName()).log(Level.SEVERE, null, ex);
            }

           
        }
    }
    
}

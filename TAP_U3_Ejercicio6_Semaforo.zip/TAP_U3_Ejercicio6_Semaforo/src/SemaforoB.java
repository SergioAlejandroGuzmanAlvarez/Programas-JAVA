
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class SemaforoB extends Thread {
    Lienzo puntero;
    int sem=0;
    public SemaforoB(Lienzo l){
        this.puntero=l;
    }
    public void pintarSemaforoB(Graphics2D g2){
        //Semaforo B
        g2.setColor(Color.ORANGE);
        g2.setStroke(new BasicStroke(3));
        g2.fillRect(740, 50, 90, 180);
        g2.setColor(Color.black);
        g2.drawRect(740, 50, 90, 180);
        //Palo B
        g2.setColor(Color.ORANGE);
        g2.setStroke(new BasicStroke(3));
        g2.fillRect(772,236, 30,60);
        g2.setColor(Color.black);
        g2.drawRect(772,236, 30,60);
    }
    public void controlSemaforo (Graphics2D g2){
        switch(sem){
            case 1:
                //Rojo B
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(763, 65, 45, 45);
                g2.setColor(Color.black);
                g2.drawOval(763, 65, 45, 45);
                //Amarillo B
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(763, 115, 45, 45);
                g2.setColor(Color.black);
                g2.drawOval(763, 115, 45, 45);
                //Verde B
                g2.setColor(Color.green);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(763, 165, 45, 45);
                g2.setColor(Color.black);
                g2.drawOval(763, 165, 45, 45);
            break;
            case 2:
               //Rojo B
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(763, 65, 45, 45);
                g2.setColor(Color.black);
                g2.drawOval(763, 65, 45, 45);
                //Amarillo B
                g2.setColor(Color.yellow);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(763, 115, 45, 45);
                g2.setColor(Color.black);
                g2.drawOval(763, 115, 45, 45);
                //Verde B
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(763, 165, 45, 45);
                g2.setColor(Color.black);
                g2.drawOval(763, 165, 45, 45);
            break;
            case 3:
                //Rojo B
                g2.setColor(Color.red);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(763, 65, 45, 45);
                g2.setColor(Color.black);
                g2.drawOval(763, 65, 45, 45);
                //Amarillo B
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(763, 115, 45, 45);
                g2.setColor(Color.black);
                g2.drawOval(763, 115, 45, 45);
                //Verde B
                g2.setColor(Color.gray);
                g2.setStroke(new BasicStroke(2));
                g2.fillOval(763, 165, 45, 45);
                g2.setColor(Color.black);
                g2.drawOval(763, 165, 45, 45);
            break;
        }
    }
    public void ColorVerde(){
        sem=1;
        puntero.repaint();
    }
    public void ColorAma(){
        sem=2;
        puntero.repaint();
    }
    public void ColorRojo(){
        sem=3;
        puntero.repaint();
    }
    @Override
    public void run() {
        while(true){
            try {
                ColorRojo();
                sleep(10000);
                ColorAma();
                sleep(5000);
                ColorVerde();
                sleep(10000);
                ColorAma();
                sleep(5000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SemaforoB.class.getName()).log(Level.SEVERE, null, ex);
            }

           
        }
    }
    
}


import java.awt.Color;
import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Autos{
    int x,y,desplazamientoX,desplazamientoY, ancho, alto;
    int x1,y1, anchoB, altoB;
    int valorA,valorB;
    Color colorRelleno, colorContorno;
    Lienzo puntero;
    public Autos(){
        x=660;
        y=(int) (Math.random() * (800 + 10));
        x1=(int)(Math.random() * (500 + 60));
        y1=390;
        ancho=30;
        alto=70;
        anchoB=100;
        altoB=30;
        colorRelleno = new Color((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255));
        colorContorno = new Color((int)(Math.random()*255),(int)(Math.random()*255),(int)(Math.random()*255));
        desplazamientoX=5;
        desplazamientoY=5;
    }
    public void pintarA(Graphics2D g2){
        g2.setColor(colorRelleno);
        g2.fillRect(x, y, ancho, alto);
        g2.setColor(colorContorno);
        g2.drawRect(x,y, ancho, alto);
    }
    public void pintarB(Graphics2D g2){
        g2.setColor(colorRelleno);
        g2.fillRect(x1, y1, anchoB, altoB);
        g2.setColor(colorContorno);
        g2.drawRect(x1,y1, anchoB, altoB);
    }
    //g2.drawRect(570, 300, 130, 130);
    public void moverA(int valor){
        //            X1  Y1     X2  Y2
        valorA=valor;
        switch(valorA){
            case 1:
                y-= desplazamientoY; //Se desplase por el semaforo A
            break;
            case 2:
                y-=13; //Se desplaze mas rapido cuando cambie a amarillo
            break;
            case 3:
                y=390;
            break;
        }
    }
    public void moverB(int valor){
        // 1 Cuando esta en verde, se acelera normal, desplazandose en y
        // 2 Cuando esta en amarillo, acelera a 5 veces mas que en desplazamientoY
        // 3 Cando esta en rojo, el carro se detiene en el cruze
        valorB=valor;
        switch(valorB){
            case 1:
                x1+=desplazamientoX+5;
            break;
            case 2:
                y1=390;
            break;
            case 3:
                x1=450;
            break;
        }
    }
}

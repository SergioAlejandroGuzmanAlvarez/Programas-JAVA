
import java.awt.BasicStroke;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Lienzo extends Canvas{
    SemaforoA a = new SemaforoA(this);
    SemaforoB b = new SemaforoB(this);
    Calles c = new Calles(this);
    Autos car, arr[];
    Lienzo l;
    //Ancho,alto
    public Lienzo(int cant){
        a.start(); 
        b.start();
        arr = new Autos[cant];
        for (int i = 0; i < arr.length; i++) {
           arr[i] = new Autos();
        }
        hiloCar.start();
    }
    Thread hiloCar = new Thread(new Runnable(){
        @Override
        public void run() {
            while(true){
                try {
                    for (int i = 0; i < arr.length; i++) {
                        switch (a.sem) {
                            case 1:
                                arr[i].moverA(1);
                                break;
                            case 2:
                                arr[i].moverA(2);
                                //g2.drawRect(570, 300, 130, 130);
                                break;
                            case 3:
                                break;
                        }
                    switch(b.sem){
                        case 1:
                            arr[i].moverB(1);
                        break;
                        case 2:
                            arr[i].moverB(2);
                        break;
                        case 3:
                            arr[i].moverB(3);
                        break;
                    }
                  }
                  repaint();
                  Thread.sleep(300);
              } catch (InterruptedException ex) {
                  Logger.getLogger(Lienzo.class.getName()).log(Level.SEVERE, null, ex);
              }  
            }
        }  
    });
    
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2 = (Graphics2D)g;
        setBackground(Color.DARK_GRAY);
        c.pintarCalles(g2);
        a.pintarSemaforoA(g2);
        a.controlSemaforo(g2);
        b.pintarSemaforoB(g2);
        b.controlSemaforo(g2);
        for (int i = 0; i < arr.length; i++) {
            g2.setStroke(new BasicStroke(1));
            arr[i].pintarA(g2);  //Pinta los carros de A Y B
            arr[i].pintarB(g2);
        }
    }
}


import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Admin
 */
public class Calles {
    Lienzo puntero;
    public Calles(Lienzo puntero) {
        this.puntero = puntero;
    } 
    public void pintarCalles(Graphics2D g2){
        //--------------CENTRO CUADRADO--------------------------
            g2.setColor(Color.white);
            g2.drawRect(570, 300, 130, 130);
        //-------------------CALLES-------------------------------------------
        //X1 ES EL PRIMER PUNTO DE LA COORDENADA EN X
        //Y1 ES EL PRIMER PUNTO DE LA COORDENADA EN Y
        //X2 ES EL SEGUNDO PUNTO DE LA COORDENADA EN X
        //Y2 ES EL SEGUNDO PUNTO DE LA COORDENADA EN Y
            g2.setColor(Color.white);
            //CALLE A - IZQUIERDA HORIZONTAL
            g2.drawLine(30,300,570,300);
            g2.drawLine(30,430,570,430);
            //CALLE A - DERECHA HORIZONTAL EJES DE LAS  X
            g2.drawLine(700,300,1330,300);
            g2.drawLine(700,430,1330,430);
            //CALLE B - SUPERIOR VERTICAL
            g2.drawLine(570, 15, 570, 300);
            g2.drawLine(700,15,700,300);
            //CALLE B - SUPERIOR INFERIOR
            g2.drawLine(570, 680, 570, 430);
            g2.drawLine(700, 680, 700, 300);
            //DIVISORES DE CALLES
            g2.setColor(Color.white);
            g2.setStroke(new BasicStroke(2));
            g2.drawLine(30, 365, 60, 365);
            g2.drawLine(70, 365, 100, 365);
            g2.drawLine(110, 365, 140, 365);
            g2.drawLine(150, 365, 180, 365);
            g2.drawLine(190, 365, 220, 365);
            g2.drawLine(230, 365, 260, 365);
            g2.drawLine(270, 365, 300, 365);
            g2.drawLine(310, 365, 340, 365);
            g2.drawLine(350, 365, 380, 365);
            g2.drawLine(390, 365, 420, 365);
            g2.drawLine(430, 365, 460, 365);
            g2.drawLine(470, 365, 500, 365);
            g2.drawLine(510, 365, 540, 365);
            g2.drawLine(730, 365, 760, 365);
            g2.drawLine(770, 365, 800, 365);
            g2.drawLine(810, 365, 840, 365);
            g2.drawLine(850, 365, 880, 365);
            g2.drawLine(890, 365, 920, 365);
            g2.drawLine(930, 365, 960, 365);
            g2.drawLine(970, 365, 1000, 365);
            g2.drawLine(1010, 365, 1040, 365);
            g2.drawLine(1050, 365, 1080, 365);
            g2.drawLine(1090, 365, 1120, 365);
            g2.drawLine(1130, 365, 1160, 365);
            g2.drawLine(1170, 365, 1200, 365);
            g2.drawLine(1210, 365, 1240, 365);
            g2.drawLine(1250, 365, 1280, 365);
            g2.drawLine(1290, 365, 1320, 365);
            g2.drawLine(640, 10, 640, 40);
            g2.drawLine(640, 50, 640, 90);
            g2.drawLine(640, 100, 640, 150);
            g2.drawLine(640, 160, 640, 200);
            g2.drawLine(640, 210, 640, 250);
            g2.drawLine(640, 260, 640, 300);
            g2.drawLine(640, 450, 640, 480);
            g2.drawLine(640, 500, 640, 530);
            g2.drawLine(640, 550, 640, 580);
            g2.drawLine(640, 600, 640, 630);
            g2.drawLine(640, 650, 640, 680);
    }
}

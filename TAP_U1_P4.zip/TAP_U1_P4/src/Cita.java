public class Cita {
    private String idP,nombre,apellidos,edad,fecha,genero,idCita,fechacita,hora;
    
    public Cita(String idP, String nombre, String apellidos, String edad, String fecha, String genero, String idCita, String fechacita, String hora) {
        this.idP = idP;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.fecha = fecha;
        this.genero = genero;
        this.idCita = idCita;
        this.fechacita = fechacita;
        this.hora = hora;
    }

    public String getIdP() {
        return idP;
    }

    public void setIdP(String idP) {
        this.idP = idP;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getIdCita() {
        return idCita;
    }

    public void setIdCita(String idCita) {
        this.idCita = idCita;
    }

    public String getFechacita() {
        return fechacita;
    }

    public void setFechacita(String fechacita) {
        this.fechacita = fechacita;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }
    
}
